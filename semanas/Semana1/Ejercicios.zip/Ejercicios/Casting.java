class Casting {
	public static void main(String [] args) {
	int x = (int)3957.229; 
	System.out.println("int x = " + x);
}
}