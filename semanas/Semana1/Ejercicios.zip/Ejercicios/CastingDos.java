class CastingDos {
	public static void main(String [] args) {
	long l = 130L;
	byte b = (byte)l;
	System.out.println("The byte is " + b);
	}
}