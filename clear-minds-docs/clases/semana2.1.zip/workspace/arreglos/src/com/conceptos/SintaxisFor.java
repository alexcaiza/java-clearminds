package com.conceptos;

public class SintaxisFor {
	public static void main(String[] args) {
		
		for (int x=0, z=1;  x<5 ; ) {			
			x++;
			System.out.println(x);
		}
		
		//Trabajo como un while si no tiene la tercera parte del for
		
	}
}
