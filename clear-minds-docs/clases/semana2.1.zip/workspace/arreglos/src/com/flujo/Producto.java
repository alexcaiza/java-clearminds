package com.flujo;

public class Producto {
	private double price;
	private String name;
	private int code;
	
	public Producto(int code) {
		
	}
	
	
}
