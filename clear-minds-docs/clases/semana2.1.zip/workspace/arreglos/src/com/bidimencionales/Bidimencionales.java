package com.bidimencionales;

public class Bidimencionales {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arreglo1[];
		
		int[][] arreglo2;
		
		int arreglo3[][];
		
		//En la definicion no va el ta�a�o, da error de compilacion, va en el new
		//int arreglo4[5][]
		
		//El primer [] corchete define el tama�o del arreglo
		arreglo1 = new int [3][];
		arreglo2 = new int [2][3];
		//arreglo3 = new int [][3]; no compila

	}

}
