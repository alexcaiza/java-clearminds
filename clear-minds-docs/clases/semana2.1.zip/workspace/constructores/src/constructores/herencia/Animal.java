package constructores.herencia;

public class Animal {
	public Animal()  {
		System.out.println("Constructor de animal");
	}
}
