package constructores.herencia;

public class Disco extends Dispositivo {
	// codigo implicito error
	/*
	public Disco() {
		super();
	}
	*/
	public Disco() {
		super(null);
	}
	
	//Primero error de compilacion primero revisar si compila si existe la opcion
	//2 min por pregunta
	//70 preguntas
	
	
	
}
