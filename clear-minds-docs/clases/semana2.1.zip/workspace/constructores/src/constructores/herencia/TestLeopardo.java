package constructores.herencia;

public class TestLeopardo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Leopardo l = new Leopardo();
	}

}
//primero ver si compila, luego ver que imprime
//Cuando se pone un contructor desaparece el constructor por defector
//instalar Kahoot
//https://kahoot.com/
//Reglas importantes de constructores
