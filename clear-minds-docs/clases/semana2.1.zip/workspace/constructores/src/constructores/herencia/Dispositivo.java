package constructores.herencia;

public class Dispositivo {

	//perdio el constructor vacio
	public Dispositivo(String x) {
		
	}
	
}
