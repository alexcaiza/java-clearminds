package constructores.herencia;

public class Leopardo extends Animal {
	public Leopardo() {
		//Llama a super() (Clase padre animal) sin parametros
		System.out.println("Constructor de leopardo");
	}
}
