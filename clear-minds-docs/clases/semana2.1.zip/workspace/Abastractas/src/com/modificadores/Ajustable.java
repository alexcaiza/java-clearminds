package com.modificadores;

public interface Ajustable {
	void ajustar(); //public
	public void m1();
	
	//protected void m2();
	
	
	//En un interface todos los metodos son public  si pone o no
	//En una interface todo es public ponga o no ponga el identificador
	
	//En una clase si no pone identificador es default (PILAS)
	
	//public
	//protected
	//defaul
	//private
	
	//En la sobrescritura los metodos sobrescritos deben poner publics y son publicos
	
}
