package com.modificadores;

public class Hija extends Padre {
	
	//SI FuncionA con public , protected MENOS RESTRICTIVO
	//NO FuncionA con DEFAULT PRIVATE
	
	protected void m1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void m2() {
		// TODO Auto-generated method stub
		
	}

}
