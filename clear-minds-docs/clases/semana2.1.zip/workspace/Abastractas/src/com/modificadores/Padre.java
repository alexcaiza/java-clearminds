package com.modificadores;

public abstract class Padre {
	
	protected abstract void m1();
	
	abstract void  m2();

}
