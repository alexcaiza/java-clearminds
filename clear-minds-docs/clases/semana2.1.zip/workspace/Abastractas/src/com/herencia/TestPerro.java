package com.herencia;

public class TestPerro {

	public static void main(String[] args) {
		
		Animal p = new Perro();
		
		

	}
	
	/*
	 Sobrescritura va a partir de la herencia
	 
	  */

}
