package com.herencia;

public class Animal {	
	
	/*
	 Animal hereda de Object 
	 */
	
	public void comer() {
		System.out.println("Animal comiendo");
	}
}
