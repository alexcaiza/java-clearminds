package com.interfaces;

import com.abstractas.Comible;

public class Res extends Comible {
	
	//Al heredar de una clase abstracta se debe implemetar los metodos abs
	//Se puede sobrescribir los metodos no abs
	
	//Cuando se define una clase abstract se queda con los metodos abstractos
	//Una clase solo puede heredar solo de una clase pero si puede de varias interfaces

	//@Override
	public void comer() {
		// TODO Auto-generated method stub
		
	}

}
