package com.interfaces;

public interface Vacia {

}
