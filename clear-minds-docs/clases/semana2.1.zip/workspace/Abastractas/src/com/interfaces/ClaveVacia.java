package com.interfaces;

public class ClaveVacia implements Vacia {

}
