package com.interfaces;

public interface Lavable {
	
	void lavar();
	public void secar();
	
	//NO compila todos los metodos deben ser abstractos
	//void metodo() {}

}
