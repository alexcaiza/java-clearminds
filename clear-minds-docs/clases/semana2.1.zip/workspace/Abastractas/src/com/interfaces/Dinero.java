package com.interfaces;

public abstract class Dinero implements Lavable {

	//public void lavar();
	
	//La clase Dinero se queda con los metodos abastractos no implementados

	public void secar() {
		
	}
	

}
