package com.interfaces;

public class Dolar extends Dinero {
	
	//Si no se quiere definir los 

	//@Override
	public void lavar() {
	}

}
