package com.interfaces;

public abstract class Test {

}
