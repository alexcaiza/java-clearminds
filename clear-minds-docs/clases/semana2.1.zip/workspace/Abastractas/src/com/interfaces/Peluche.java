package com.interfaces;

public class Peluche implements Lavable {
	
	//Si no implementa los metodos de la interface da error de compilacion
	
	//anotacions de compilacion y ejecucion
	//Con overwrite o sin compila en compilacion desaparece el overwrite

	
	//anotacion de compilacion
	//@Override
	public void lavar() {
		// TODO Auto-generated method stub
		
	}

	//@Override
	public void secar() {
		// TODO Auto-generated method stub
		
	}

}
